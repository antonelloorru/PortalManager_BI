<?php
/**
 * PortalManager — Config.php
 * Riconfigurato per nuovo server: P:\xampp\htdocs\portalmanager
 * Database: portalmanager
 */

// 1. Caricamento ambiente locale (.env.php) se presente
$envFile = __DIR__ . '/.env.php';
$env = file_exists($envFile) ? (array)@include($envFile) : [];

// 2. Parametri DB con gerarchia: getenv() > .env.php > fallback predefiniti
if (!defined('DB_HOST'))    define('DB_HOST',    getenv('DB_HOST') ?: ($env['DB_HOST'] ?? 'localhost'));
if (!defined('DB_PORT'))    define('DB_PORT',    getenv('DB_PORT') ?: ($env['DB_PORT'] ?? '3306'));
if (!defined('DB_NAME'))    define('DB_NAME',    getenv('DB_NAME') ?: ($env['DB_NAME'] ?? 'portalmanager'));
if (!defined('DB_USER'))    define('DB_USER',    getenv('DB_USER') ?: ($env['DB_USER'] ?? 'root'));
if (!defined('DB_PASS'))    define('DB_PASS',    getenv('DB_PASS') !== false ? getenv('DB_PASS') : ($env['DB_PASS'] ?? ''));
if (!defined('DB_CHARSET')) define('DB_CHARSET', getenv('DB_CHARSET') ?: ($env['DB_CHARSET'] ?? 'utf8mb4'));

if (!defined('APP_ROOT'))   define('APP_ROOT',   __DIR__);
if (!defined('APP_BASE'))   define('APP_BASE',   __DIR__);
if (!defined('UPLOAD_DIR')) define('UPLOAD_DIR', APP_ROOT . '/uploads/');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => true,
        ]
    );
} catch (\PDOException $e) {
    if (PHP_SAPI === 'cli' && defined('CLI_OPTIONAL_DB') && CLI_OPTIONAL_DB) {
        $pdo = null;
        return;
    }
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, "[ERRORE DB] Impossibile connettersi al database MySQL: " . $e->getMessage() . "\nVerificare i parametri in Config.php.\n");
        exit(1);
    }
    http_response_code(503);
    $debug = false;
    if (file_exists(__DIR__ . '/.env.php')) {
        $env = @include __DIR__ . '/.env.php';
        $debug = is_array($env) && (($env['APP_DEBUG'] ?? '0') === '1');
    }
    $detail = $debug ? htmlspecialchars($e->getMessage()) : 'Impossibile connettersi al database. Verificare la configurazione del server.';
    die('<div style="font-family:sans-serif;padding:40px;background:#fee2e2;color:#991b1b;border-radius:8px;margin:40px auto;max-width:500px">
         <h2>&#9888; Errore connessione DB</h2>
         <p style="margin-top:10px">Dettaglio: <code style="background:#fff;padding:2px 6px;border-radius:3px">'
         . $detail . '</code></p>
         <p style="margin-top:10px">Verificare i parametri di connessione in <code>Config.php</code>.</p>
         </div>');
}
