-- migration_v1_9_69.sql — SSO Microsoft 365 / MFA: test di verifica configurazione.
-- Include (idempotente) il permesso della pagina sso_settings di v1.9.68. Nessun delta schema.

CREATE TABLE IF NOT EXISTS `pm_migration_sql` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `version` varchar(20) NOT NULL, `filename` varchar(190) NOT NULL,
  `applied_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`), UNIQUE KEY `uq_pm_migration_v_f` (`version`,`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `role_permissions`
  (`role_id`,`page_name`,`can_view`,`can_create`,`can_edit`,`can_delete`,`can_export`)
VALUES (1,'sso_settings.php',1,1,1,0,0)
ON DUPLICATE KEY UPDATE `can_view`=1, `can_edit`=1;

UPDATE `app_settings` SET `setting_value`='1.9.69'
 WHERE `setting_key` IN ('app_version','schema_version','release_label');

INSERT IGNORE INTO `pm_migration_sql` (`version`,`filename`) VALUES
 ('1.9.68','migration_v1_9_68.sql'),
 ('1.9.69','migration_v1_9_69.sql');
