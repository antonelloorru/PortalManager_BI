<?php
/**
 * PortalManager — Config.php
 * Riconfigurato per nuovo server: P:\xampp\htdocs\portalmanager
 * Database: portalmanager
 */

define('DB_HOST',    'localhost');
define('DB_PORT',    '3306');
define('DB_NAME',    'portalmanager');     // <-- nuovo nome DB
define('DB_USER',    'root');
define('DB_PASS',    '');                  // <-- inserire eventuale password root
define('DB_CHARSET', 'utf8mb4');

define('APP_ROOT',   __DIR__);
define('UPLOAD_DIR', APP_ROOT . '/uploads/');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => true,
        ]
    );
} catch (\PDOException $e) {
    if (PHP_SAPI === 'cli' && defined('CLI_OPTIONAL_DB') && CLI_OPTIONAL_DB) {
        $pdo = null;
        return;
    }
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, "[ERRORE DB] Impossibile connettersi al database MySQL: " . $e->getMessage() . "\nVerificare i parametri in Config.php.\n");
        exit(1);
    }
    http_response_code(503);
    $debug = false;
    if (file_exists(__DIR__ . '/.env.php')) {
        $env = @include __DIR__ . '/.env.php';
        $debug = is_array($env) && (($env['APP_DEBUG'] ?? '0') === '1');
    }
    $detail = $debug ? htmlspecialchars($e->getMessage()) : 'Impossibile connettersi al database. Verificare la configurazione del server.';
    die('<div style="font-family:sans-serif;padding:40px;background:#fee2e2;color:#991b1b;border-radius:8px;margin:40px auto;max-width:500px">
         <h2>&#9888; Errore connessione DB</h2>
         <p style="margin-top:10px">Dettaglio: <code style="background:#fff;padding:2px 6px;border-radius:3px">'
         . $detail . '</code></p>
         <p style="margin-top:10px">Verificare i parametri di connessione in <code>Config.php</code>.</p>
         </div>');
}
